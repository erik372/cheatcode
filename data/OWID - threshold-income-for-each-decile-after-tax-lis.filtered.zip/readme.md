# Threshold income for each decile (after tax) - Data package

This data package contains the data that powers the chart ["Threshold income for each decile (after tax)"](https://ourworldindata.org/grapher/threshold-income-for-each-decile-after-tax-lis?v=1&csvType=filtered&useColumnShortNames=false) on the Our World in Data website.

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The remaining columns are the data columns, each of which is a time series. If the CSV data is downloaded using the "full data" option, then each column corresponds to one time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data columns are transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

### How we process data at Our World In Data
All data and visualizations on Our World in Data rely on data sourced from one or several original data providers. Preparing this original data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/)

## Detailed information about each time series


## Poorest decile
The level of income per year below which 10% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “Poorest decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 2nd decile
The level of income per year below which 20% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “2nd decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 3rd decile
The level of income per year below which 30% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “3rd decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 4th decile
The level of income per year below which 40% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “4th decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 5th decile (median)
The level of income per year below which 50% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “5th decile (median) – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 6th decile
The level of income per year below which 60% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “6th decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 7th decile
The level of income per year below which 70% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “7th decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## 8th decile
The level of income per year below which 80% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “8th decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


## Richest decile
The level of income per year below which 90% of the population falls.
Last updated: July 23, 2025  
Next update: October 2025  
Date range: 1963–2023  
Unit: international-$ in 2017 prices  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Luxembourg Income Study (2025) – with major processing by Our World in Data

#### Full citation
Luxembourg Income Study (2025) – with major processing by Our World in Data. “Richest decile – Luxembourg Income Study” [dataset]. Luxembourg Income Study, “Luxembourg Income Study (LIS)” [original data].
Source: Luxembourg Income Study (2025) – with major processing by Our World In Data

### What you should know about this data
* The data is measured in international-$ at 2017 prices – this adjusts for inflation and for differences in living costs between countries.
* Income is "post-tax" — measured after taxes have been paid and most government benefits have been received.
* Income has been equivalized – adjusted to account for the fact that people in the same household can share costs like rent and heating.

### Source

#### Luxembourg Income Study – Luxembourg Income Study (LIS)
Retrieved on: 2025-06-27  
Retrieved from: https://www.lisdatacenter.org/our-data/lis-database/  

#### Notes on our processing step for this indicator
We create the Luxembourg Income Study data from standardized household survey microdata available in their [LISSY platform](https://www.lisdatacenter.org/data-access/lissy/). The estimations follow the methodology available in LIS, Key Figures and DART platform.

We obtain after tax income by using the disposable household income variable (`dhi`).

We estimate before tax income by calculating the sum of income from labor and capital (variable `hifactor`), cash transfers and in-kind goods and services from privates (`hiprivate`) and private pensions (`hi33`). We do this only for surveys where tax and contributions are fully captured, collected or imputed.

We obtain after tax income (cash) by using the disposable household cash income variable (`dhci`).

We convert income data from local currency into international-$ by dividing by the [LIS PPP factor](https://www.lisdatacenter.org/resources/ppp-deflators/), available as an additional database in the LISSY platform.

We top and bottom-code incomes by replacing negative values with zeros and setting boundaries for extreme values of log income: at the top Q3 plus 3 times the interquartile range (Q3-Q1), and at the bottom Q1 minus 3 times the interquartile range.

We equivalize incomes by dividing each household observation by the square root of the number of household members (nhhmem). Per capita estimates are calculated by dividing incomes by the number of household members.


Income shares and thresholds by decile are obtained by using [Stata’s sumdist function](https://ideas.repec.org/c/boc/bocode/s366005.html). We set weights as the product between the number of household members (nhhmem) and the normalized household weight (hwgt) and the number of quantile groups as 10. We estimate threshold ratios, share ratios and averages by decile in Python after processing in the LISSY platform.


    